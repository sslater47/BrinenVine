export default function Cancel(){
  return (<div className="card"><h1 className="text-2xl font-bold">Checkout canceled</h1><p className="mt-2">You haven’t been charged. You can resume your order anytime.</p></div>);
}
