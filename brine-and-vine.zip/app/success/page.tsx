export default function Success(){
  return (<div className="card"><h1 className="text-2xl font-bold">Thank you!</h1><p className="mt-2">Your order was placed. A confirmation email is on the way.</p></div>);
}
